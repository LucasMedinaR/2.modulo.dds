/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_3_lucas;

/**
 *
 * @author lramos
 */
public class Atividade_3_Lucas {

    public static void main(String[] args) {
        System.out.println("Ola mundo!");
    }
}
