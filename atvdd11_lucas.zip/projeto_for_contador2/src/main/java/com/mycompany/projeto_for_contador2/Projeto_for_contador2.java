/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_for_contador2;

/**
 *
 * @author lramos
 */
public class Projeto_for_contador2 {

    public static void main(String[] args) {
        
        
        for(int i=10; i>=1;i--){
            System.out.println(i);
                
    }
}
}