/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_13_lucas;

import java.util.Scanner;
/**
 *
 * @author lramos
 */
public class PROJETO_13_LUCAS {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        {   
        System.out.println("Digite um valor");
         int ValorUm = ler.nextInt();
    
        System.out.println("Digite um valor");
         int ValorDois = ler.nextInt();
    
   
         System.out.println("O primeiro numero digitado foi:");
         System.out.println(ValorUm);
         System.out.println("O segundo numero digitado foi:");
          System.out.println(ValorDois);       
         
}
}
    }