/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_for_contador;


/**
 *
 * @author lramos
 */
public class Projeto_For_contador {

 public static void main(String[] args) {
   
        
          for(int i=1 ;i<=10; i++){
            System.out.println(i);
         
        
    }
    }
}
