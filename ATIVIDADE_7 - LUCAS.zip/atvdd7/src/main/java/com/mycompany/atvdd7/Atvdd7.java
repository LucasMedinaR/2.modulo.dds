/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atvdd7;

/**
 *
 * @author lramos
 */
public class Atvdd7 {

    public static void main(String[] args) {
        
        int x=10;
        int y=3;
               
        System.out.println(x+y);
        System.out.println(x-y);
        System.out.println(x*y);
        System.out.println(x+1);
        
    }
}
