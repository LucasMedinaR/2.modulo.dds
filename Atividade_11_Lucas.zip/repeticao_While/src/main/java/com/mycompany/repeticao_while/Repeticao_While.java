/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.repeticao_while;

import java.util.Scanner;

/**
 *
 * @author lramos
 */
public class Repeticao_While {

    public static void main(String[] args) {
       
        Scanner ler = new Scanner (System.in);
        
        System.out.println("Digite um numero");
          int product = ler.nextInt();
          
     while(product <= 10)
        
     {
         product=3*product;
         
             System.out.println(product);
             } 
    }
}
