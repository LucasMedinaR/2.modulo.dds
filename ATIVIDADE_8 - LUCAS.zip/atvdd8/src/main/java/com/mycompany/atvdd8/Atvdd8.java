/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atvdd8;

/**
 *
 * @author lramos
 */
public class Atvdd8 {

    

    public static void main(String[] args) {
        
        int x=10;
        int y=3;
               
        System.out.println(x+1);
        System.out.println(x/2);
        System.out.println(x+x+y+1);
        System.out.println(24/y);
        
    }

    }

