/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_12_emposto_estado_lucas;

import java.util.Scanner;
/**
 *
 * @author lramos
 */
public class Projeto_12_emposto_estado_Lucas {
   

    public static void main(String[] args) {
         Scanner ler = new Scanner (System.in);

        System.out.println("Digite o valor da sua compra");
           float Valor = ler.nextFloat();
           
        
         
        System.out.println("Digite a sigla do seu estado");
          String Estado= ler.next();
          
          
          if
            (Estado.equalsIgnoreCase("MG")){
              System.out.println(Valor+(Valor*0.07));
          }
          else if(Estado.equalsIgnoreCase ("SP" )){
              System.out.println(Valor+(Valor*0.12));
          }
          else if(Estado.equalsIgnoreCase ("RJ")){
              System.out.println(Valor+(Valor*0.15));  
          }
          else if(Estado.equalsIgnoreCase ("MS")){
              System.out.println(Valor+(Valor*0.08));
          }
          else 
              System.out.println("Erro! Digite novamente");
    }
}
