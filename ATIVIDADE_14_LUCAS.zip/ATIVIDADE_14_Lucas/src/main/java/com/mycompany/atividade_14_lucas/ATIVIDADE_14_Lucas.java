/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_14_lucas;

import java.util.Scanner;
/**
 *
 * @author lramos
 */
public class ATIVIDADE_14_Lucas {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
    
        
                System.out.println("Digite sua primeira nota");
                 int NotaUm = ler.nextInt();
                
                
                
                System.out.println("Digite sua segunda nota");
                 int NotaDois = ler.nextInt();
              
                 
                 
                
                     
                         
                         
                 
     
                  
                  
                  
                  if(NotaUm >= 0 && NotaUm <= 10 && NotaDois >= 0 && NotaDois <= 10){
                    System.out.println("Sua media e:");
                    int media = (NotaUm+NotaDois)/2;
                    System.out.println(media);
                  }
    
    }
} 
               
               
                 
                              
              
                         
                 
                            
                            
                 
                 
                   
                             
    

