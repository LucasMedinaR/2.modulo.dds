/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_5_lucas;

/**
 *
 * @author lramos
 */
public class Atividade_5_Lucas {

    public static void main(String[] args) {
        System.out.println("Olá Mundo!\n");
        System.out.println("Até logo!\n");
        System.out.println("Estou de volta!\n");
    }
}
