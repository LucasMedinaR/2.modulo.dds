/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_4_lucas;

/**
 *
 * @author lramos
 */
public class Atividade_4_Lucas {

    public static void main(String[] args) {
        System.out.println("Olá Mundo!\n");
        System.out.println("Até logo!\n");
    }
}
