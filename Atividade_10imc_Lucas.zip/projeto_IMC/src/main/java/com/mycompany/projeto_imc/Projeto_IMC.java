/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_imc;

import java.util.Scanner;
/**
 *
 * @author lramos
 */
public class Projeto_IMC {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
         Scanner ler = new Scanner (System.in);
        
        System.out.println("Digite sua altura");
          float Altura = ler.nextFloat();
          
        System.out.println("Digite seu peso");
          float peso = ler.nextFloat();
          
          System.out.println();
          
          
          float imc = peso / Altura;
          
          System.out.print(imc
          );
    }
}
