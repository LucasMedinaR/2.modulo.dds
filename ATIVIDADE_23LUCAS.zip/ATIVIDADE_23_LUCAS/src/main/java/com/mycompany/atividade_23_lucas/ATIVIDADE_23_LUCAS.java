/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade_23_lucas;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author lramos
 */
public class ATIVIDADE_23_LUCAS {

    public static void main(String[] args) throws IOException {
        
        String s="";
        
        float v[] =new float[4];
        float media=0, soma=0;
        DataInputStream dado;
       
        
        for(int i=0;i<4;i++){
        System.out.println("Digite a "+(i+1) +"º nota");
        dado = new DataInputStream(System.in);
        
        s = dado.readLine();//lê uma linha do teclado
        v[i] = Float.parseFloat(s);
    }
      for(int i=0;i<4;i++){
          soma = soma+v[i];
          
    }
        
        media = soma/4;
        System.out.println(media);
       
    }
}
