/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atvdd9;

/**
 *
 * @author lramos
 */
public class Atvdd9 {

    public static void main(String[] args) {
        
        boolean temSaldo=true;
        boolean limiteDisponivel=false;        
        
        
        System.out.println(limiteDisponivel);
        System.out.println(temSaldo);
        System.out.println(limiteDisponivel);
        
    }
}
